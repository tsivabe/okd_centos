#!/bin/bash

export DOMAIN="" 
export USERNAME="" 
export PASSWORD="" 
export SCRIPT_REPO=""
export IP="" 
export DISK="" 
